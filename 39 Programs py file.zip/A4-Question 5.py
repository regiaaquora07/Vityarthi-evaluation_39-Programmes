#Programme-5
import time,sys
n=int(input("Enter the number :"))
st=time.perf_counter()
def count_divisors(n):
    c=0
    i=1
    while i * i<=n:
        if n % i==0:
            if i * i==n:
                c+=1   
            else:
                c+=2  
        i+=1
    return c
x=count_divisors(n)
print(x)
et=time.perf_counter()
ent=et-st
print(f"Program execution time:{ent:4f}seconds")
mem_n = sys.getsizeof(n)
mem_count = sys.getsizeof(count_divisors(n))
mem_total = mem_n + mem_count
print("Approximate memory used (bytes):", mem_total)
