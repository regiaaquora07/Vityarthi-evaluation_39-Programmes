#Programme-1
import time,sys
n=int(input("Enter the number :"))
st=time.perf_counter()
def count_distinct_prime_factors(n):
    c=0
    i=2
    while i * i<=n:
        if n % i==0:
            c += 1
            while n % i==0:
                n //= i
        i += 1
    if n > 1:
        c+=1
    return c
x=count_distinct_prime_factors(n)
print(x)
et=time.perf_counter()
ent=et-st
print(f"Program execution time:{ent:4f}seconds")
mem_n = sys.getsizeof(n)
mem_count = sys.getsizeof(count_distinct_prime_factors(n))
mem_total = mem_n + mem_count
print("Approximate memory used (bytes):", mem_total)
