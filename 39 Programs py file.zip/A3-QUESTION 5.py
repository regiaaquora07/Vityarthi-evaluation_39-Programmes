#Programme-5
import time,sys
n=int(input("Enter the number :"))
st=time.perf_counter()
def prime(n):
    prime = []
    i = 2
    while i * i <= n:
        if n % i == 0:
            prime.append(i)
            while n % i == 0:
                n //= i
        i += 1
    if n > 1:
        prime.append(n)
    return prime
x=prime(n)
print(x)
et=time.perf_counter()
ent=et-st
print(f"Program execution time:{ent:4f}seconds")
mem_n = sys.getsizeof(n)
mem_count = sys.getsizeof(prime(n))
mem_total = mem_n + mem_count
print("Approximate memory used (bytes):", mem_total)

