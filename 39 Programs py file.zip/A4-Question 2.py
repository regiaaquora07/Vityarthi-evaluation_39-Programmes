#Programme-2
import time,sys
n=int(input("Enter the number :"))
st=time.perf_counter()
def is_prime_power(n):
    a=0
    if n < 2:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            a+=1
    if n < 2:
        return False
    for k in range(1, int(n ** 0.5) + 2):
        p = round(n ** (1 / k))
        if p ** k==n and a==0:
            return "False"
    return "True"
x=is_prime_power(n)
print(x)
et=time.perf_counter()
ent=et-st
print(f"Program execution time:{ent:4f}seconds")
mem_n = sys.getsizeof(n)
mem_count = sys.getsizeof(is_prime_power(n))
mem_total = mem_n + mem_count
print("Approximate memory used (bytes):", mem_total)

